def upsert_to_dynamodb(item):
    return True
